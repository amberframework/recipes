
npm i --save react-router-dom react redux react-redux redux-thunk redux-logger
npm i --save-dev babel-core babel-preset-env babel-preset-react babel-preset-stage-2
npm i --save-dev babel-loader css-loader file-loader node-sass sass-loader style-loader webpack webpack-merge extract-text-webpack-plugin
npm i --save-dev babel-plugin-transform-decorators-legacy

# eslint
# npm i --save-dev babel-eslint eslint-config-google eslint-plugin-react

# jest
# npm i --save-dev babel-jest
